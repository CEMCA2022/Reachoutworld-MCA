<?php
session_start();
// LOGIN USER
		$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');
if (isset($_POST['login'])) {
	$clearance_Id = mysqli_real_escape_string($db, $_POST['clearance_Id']);
	$password = mysqli_real_escape_string($db, $_POST['password']);

	if (empty($clearance_Id)) {
		$message = "clearance Id is required";
	}
	if (empty($password)) {
		$message = "Password is required";
	}

	if (count($errors) == 0) {

		$query = "SELECT * FROM adminUsers WHERE clearance_Id='$clearance_Id' AND password='$password'";
		$results = mysqli_query($db, $query);

		if (mysqli_num_rows($results) == 1) {
			$_SESSION['clearance_Id'] = $clearance_Id;
			$_SESSION['success'] = "You are now logged in";
			header('location: ../redeemOrder.php');
		}else {
			$message ="Wrong username/password combination";
		}
	}
}

?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="./style.css">


</head>

<body>


<div class="container">
  <div class="info">
    <h1>Cellulant Blockchain </h1><span>Senior Clearance Admin Login</span>
		<center style="color:red"><?php echo $message ?></center>
  </div>

</div>

<div class="form" action="login.php"  method="post">

  <div class=""><img src="images/protection2.png"/></div>
  <form class="register-form">
    <input type="text" placeholder="name"/>
    <input type="password" placeholder="password"/>
    <input type="text" placeholder="email address"/>
    <button>create</button>
    <p class="message">Already registered? <a href="#">Sign In</a></p>
  </form>
  <form class="login100-form validate-form flex-sb flex-w" action="login.php"  method="post">
        <input type="text" placeholder="Clearance ID" name="clearance_Id" style="text-align:center"/>
    <input type="password" placeholder="password" name="password" style="text-align:center"/>
    <button name="login">login</button>

  </form>
</div>
<video id="video" autoplay="autoplay" loop="loop" poster="polina.jpg">
  <source src="http://andytran.me/A%20peaceful%20nature%20timelapse%20video.mp4" type="video/mp4"/>
</video>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>



    <script  src="./script.js"></script>




</body>

</html>
