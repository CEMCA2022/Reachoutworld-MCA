<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Tanadi Discount Sales | Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">


    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>

	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">Tanadi.com.ng</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item active"><a href="index.html" class="nav-link"></a></li>
	        	<li class="nav-item"><a href="about.html" class="nav-link"></a></li>
	        	<li class="nav-item"><a href="menu.html" class="nav-link"></a></li>
	        	<li class="nav-item"><a href="blog.html" class="nav-link"></a></li>
	          <li class="nav-item"><a href="contact.html" class="nav-link"></a></li>
	          <li class="nav-item cta"><a href="../index.php" class="nav-link" style="border-radius:80px">CREATE AN ORDER </a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

    <section class="home-slider owl-carousel js-fullheight">
      <div class="slider-item js-fullheight" style="background-image: url(image/ok33.jpg);">
      	<!-- <div class="overlay"></div> -->
        <div class="container">
          <div class="row slider-text js-fullheight justify-content-center align-items-center" data-scrollax-parent="true">

            <div class="col-md-12 col-sm-12 text-center ftco-animate">
            	<span class="subheading" style="color:red">LockDown Discount Sales</span>
              <h1 class="mb-4" style="font-size:35px">To Cushion the effect of the LOCKDOWN. And as a Paliative to help us Survive the Challenging Season.</h1>
            </div>

          </div>
        </div>
      </div>

      <!--  -->

    </section>

    <section class="ftco-section ftco-no-pt ftco-no-pb">
    	<div class="container-fluid">
    		<div class="row">
    			<div class="col-md-12">
    				<div class="featured">
    					<div class="row">
     <div class="col-md-2">
        <a href="../redeem/redeemOrder.php" class="nav-link">
    							<div class="featured-menus ftco-animate"  style="border:5px solid #fff; border-radius:7px;opacity:1;height:100px">
			              <div class="text text-center">
		                  <h3 style="color:red;font-size:26px">REDEEM ORDER</h3>
				              <!-- <p><span>Eighteen thousand Naira (18,000)</span></p> -->
			              </div>
			            </div>
                 </a>
    						</div>
    		  <div class="col-md-2" >
        <a href="../agentReg.php" class="nav-link">
    							<div class="featured-menus ftco-animate" style="border:5px solid #fff; border-radius:7px;opacity:1;height:100px">
			              <div class="text text-center">
		                  <h3 style="color:red;font-size:26px">CREATE AGENT</h3>

			              </div>
			            </div>
                </a>
    						</div>

      <div class="col-md-2" >
        <a href="../orderDb.php" class="nav-link">
    							<div class="featured-menus ftco-animate" style="border:5px solid #fff; border-radius:7px;opacity:0.4px;height:100px">
			              <div class="text text-center">
		                  <h3 style="color:red;font-size:26px">ORDER DATABASE</h3>

			              </div>
			            </div>
               </a>
    						</div>
          <div class="col-md-2" >
            <a href="../redemptionDb.php" class="nav-link">
           <div class="featured-menus ftco-animate" style="border:5px solid #fff; border-radius:7px;opacity:1;height:100px">
                 <div class="text text-center" >
                    <h3 style="color:red;font-size:20px " >REDEMPTION DATABASE</h3>

                 </div>
               </div>
               </a>
          </div>
        <div class="col-md-2" >
          <a href="../agentDb.php" class="nav-link">
           <div class="featured-menus ftco-animate" style="border:5px solid #fff; border-radius:7px;opacity:1;height:100px ">
                 <div class="text text-center">
                    <h3 style="color:red;font-size:26px " >AGENT DATABASE</h3>

                 </div>
               </div>
               </a>
          </div>
    			  <div class="col-md-2" >
          <a href="../tokenGen.php" class="nav-link">
    							<div class="featured-menus ftco-animate" style="border:5px solid #fff; border-radius:7px;opacity:1; height:100px; ">
			              <!-- <div class="menu-img img" style="background-image: url(image/database.jpeg);"></div> -->
			              <div class="text text-center">
		                  <h3 style="color:red;font-size:26px " >GENERATE TOKEN</h3>

			              </div>
			            </div>
               </a>
    						</div>
    					</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </section>




  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>

  </body>
</html>
