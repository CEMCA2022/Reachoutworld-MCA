<?php
session_start();
	include("functions.php");

	// Turn off all error reporting
	error_reporting(0);
	// variable declaration
	$errname = "";
	$errquantity = "";
	$errphone= "";
	$erraddress = "";
		$errsize = "";

$successMessage="";
	$name = "";
	$quantity = "";
	$phone = "";
	$address = "";
		$size = "";


	$errors = array();
	$messages= array();
	$_SESSION['success'] = "";
	// $admin_address = "0x2d2d8721fcacb58c7f5f2946bdcc487629da2d64";
	// $admin_token = getToken('admin', 'Agrikore8546&');

	$farmers = fetchFromDatabase('localhost', 'ebube', 'advancegrace', 'tanadi', 'order_table');
	$status = 0;
	// connect to database
	$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');

	// REGISTER USER
	if (isset($_POST['check'])) {

		$name = mysqli_real_escape_string($db, $_POST['name']);
		$quantity = mysqli_real_escape_string($db, $_POST['quantity']);
		$phone = mysqli_real_escape_string($db, $_POST['phone']);
		$address = mysqli_real_escape_string($db, $_POST['address']);
				$size = mysqli_real_escape_string($db, $_POST['size']);





		if (empty($name)) { array_push($errors, "Full Name is required"); }
		if(!preg_match("/^[A-Za-z0-9]*${4}/", $name)){
		$errname = '<p class="$errusername">Full Name Must contain letters or digit,and should be more than 3 characters</p>';
		 array_push($errors, $errname);
		}
		if(strlen($name) <= 1){
		$errname = '<p class="errpassword"> Full Name Must contain letters or digit,and should be more than 3 characters </p>';
		array_push($errors, $errname);}



		if (empty($phone)) { array_push($errors, "Phone Number is required"); }
		if(strlen($phone) != 11){
		$errphone = '<p class="errText">Phone must comply with this mask: XXX-XXX-XXX-XX 11 Digit</p>';
		array_push($errors, $errphone);}

		if(empty($size)){
		$errsize = '<p class="errText">Size of Bags is Required</p>';
		array_push($errors, $errsize);}

		if($size==0){
		$errsize = '<p class="">Size of Bags is Required</p>';
		array_push($errors, $errsize);}

		if (empty($quantity)) { array_push($errors, "Number of Bags Or Quantity is Required"); }


		if (empty($address)) { array_push($errors, "Full Name is required"); }
		if(!preg_match("/^[A-Za-z0-9]*${4}/", $address)){
		$erraddress = '<p class="$errusername">Full Name Must contain letters or digit,and should be more than 3 characters</p>';
		 array_push($errors, $erraddress);
		}

						//This is how i check for multiple entry

											// connect to database
											$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');

										$query = "SELECT * FROM order_table WHERE  phone='$phone'";
										$results = mysqli_query($db, $query);
										if (mysqli_num_rows($results) > 0) {
											$errphone = '<p class="$errusername">Sorry the Mobile Number already Exit in the System</p>';
											array_push($errors, $errphone);
										}


		// register user if there are no errors in the form
		elseif (count($errors) == 0) {

			$digit= $phone;
			$no_of_digits=5;
			$var='';
			for($i=1; $i<=$no_of_digits; $i++){
			$var .=rand(0,9);
			$lastdigits = substr($digit, -4);
			$redeem_code= "TAN/DIS/$var/$lastdigits";
			}
			if(!empty($redeem_code)){

      InsertUser('localhost', 'ebube', 'advancegrace', 'tanadi', 'order_table', $name, $quantity, $phone,$address,$redeem_code, $size);

						$messagesSuccess = "Congratulations! $name. New Order Created Successfully, Your REDEEM CODE is $redeem_code";
						// array_push($messages, $successMessage);


						$name = "";
						$quantity = "";
						$phone = "";
						$address = "";
						$redeem_code= "";
						$size= "";

}
}
}
	// ...

	// LOGIN USER
	if (isset($_POST['login_user'])) {
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password = mysqli_real_escape_string($db, $_POST['password']);

		if (empty($username)) {
			array_push($errors, "Username is required");
		}
		if (empty($password)) {
			array_push($errors, "Password is required");
		}

		if (count($errors) == 0) {
			$password = md5($password);
			$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
			$results = mysqli_query($db, $query);

			if (mysqli_num_rows($results) == 1) {
				$_SESSION['username'] = $username;
				//$_SESSION['success'] = "You are now logged in";
				header('location: index.php');
			}else {
				array_push($errors, "Wrong username/password combination");
			}
		}
	}

?>
