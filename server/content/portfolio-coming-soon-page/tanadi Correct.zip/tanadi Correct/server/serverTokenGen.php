<?php
session_start();
	include("functions.php");
	// Turn off all error reporting
	error_reporting(0);
	// variable declaration

	$errpassword_1 = "";

$successMessage="";

	$password_1 = "";


	$errors = array();
	$messages= array();
	$_SESSION['success'] = "";
	// $admin_address = "0x2d2d8721fcacb58c7f5f2946bdcc487629da2d64";
	// $admin_token = getToken('admin', 'Agrikore8546&');

	$farmers = fetchFromDatabase('localhost', 'ebube', 'advancegrace', 'tanadi', 'token_table');
	$status = 0;
	// connect to database
	$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');

	// REGISTER USER
	if (isset($_POST['pass'])) {

		$password_1 = mysqli_real_escape_string($db, $_POST['password_1']);


$password_1 =md5($password_1);



		if (empty($password_1)) { array_push($errors, "Please Enter a password"); }
		if(strlen($password_1) < 11){
		$errpassword_1 = '<p class="errText">Please Agent Password should be Minimum of 11 Characters</p>';
		array_push($errors, $errpassword_1);}
						//This is how i check for multiple entry

											// connect to database
											$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');

										$query = "SELECT password FROM master_table ";
										$results = mysqli_query($db, $query);
										$row = $results->fetch_assoc();
											$masterPass= $row['password'];
											if ($password_1 != $masterPass) {
												$errpassword_1 = '<p class="$errusername">Sorry the Admin Password is Incorrect </p>';
												array_push($errors, $errpassword_1);
											}


		// register user if there are no errors in the form
												elseif (count($errors) == 0) {
													$digit= $phone;
													$no_of_digits=5;
													$var='';
													for($i=1; $i<=$no_of_digits; $i++){
													$var .=rand(0,9);
													$var = substr($var, -4);
													$token= "TAN/TOKEN/$var";
													}


			if(!empty($token)){

      InsertToken('localhost', 'ebube', 'advancegrace', 'tanadi', 'token_table', $token);
 						// updateTokenTable('localhost', 'ebube', 'advancegrace', 'tanadi', 'token_table', $token);
						$messagesSuccess = "Congratulations! Admin , Your TOKEN is $token";
						// array_push($messages, $successMessage);
						$token = "";
						$password_1 = "";


}
}
}
	// ...

	// LOGIN USER
	if (isset($_POST['login_user'])) {
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password = mysqli_real_escape_string($db, $_POST['password']);

		if (empty($username)) {
			array_push($errors, "Username is required");
		}
		if (empty($password)) {
			array_push($errors, "Password is required");
		}

		if (count($errors) == 0) {
			$password = md5($password);
			$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
			$results = mysqli_query($db, $query);

			if (mysqli_num_rows($results) == 1) {
				$_SESSION['username'] = $username;
				//$_SESSION['success'] = "You are now logged in";
				header('location: index.php');
			}else {
				array_push($errors, "Wrong username/password combination");
			}
		}
	}

?>
