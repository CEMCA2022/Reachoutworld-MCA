<?php
include('header.php');
?>
<title>Tanadi Discount Sales Db</title>
<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/style3.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" type="text/css" href="arrow.css">

    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="script/script.js"></script>
<?php include('containerToken.php');?>

<thead class="table100 ver4 m-b-110" >
  <center><h2 style="font-size:38px; color:white; font-family: Times New Roman, Times, serif;margin-top:25px" > TANADI DISCOUNT TOKEN DATABASE</h2>
<hr style="max-width:200px; height:3px; background-color:#ffffff">
</center>

</thead>
		<table id="tokenTable" data-vertable="ver2"   class="display" width="100%" cellspacing="0">
    <thead style="background-color:#19194d; color:white;
  line-height: 1.4;font-family: Montserrat-Medium; background-color: #86592d;font-size: 15px;color: #fff;text-transform: uppercase;">
                <tr class="row100 head" style="height:70px">
              <th class="column100 column1" data-column="column1">ID</th>
              <th class="column100 column6" data-column="column6">TOKEN</th>
              <th class="column100 column6" data-column="column6">STATUS</th>
              <th class="column100 column6" data-column="column6">CREATION DATE</th>


            </tr>
        </thead>
    </table>


</div>
<?php include('footer.php');?>
