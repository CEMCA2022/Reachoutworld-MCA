<?php
session_start();
include("functionsG.php");
require 'PHPMailerAutoload.php';
$_SESSION['success'] = "";
	// variable declaration
	$location_name = "";
	$location_coord = "";
	$country = "";
	$state="";
	$locality="";
	$postal="";
	$status=0;
	$errors = array();
	$messages= array();
	$admin_token = getToken('admin', 'Agrikore8546&');
	$admin_password ="agrikore";
	// echo "<pre>$admin_token</pre>";
	$admin_address = "0x2d2d8721fcacb58c7f5f2946bdcc487629da2d64";
 $password="123456";
 $bonded_value = 0;
 $interest_rate = 0;
 $handle =0;
 $extra_buy_price = 0;
  $credit_percent = 0;
  $is_offtaker_funded="true";
  $pay_commas_derivative="true";
	// connect to database
	$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'agrikorefund');

	// REGISTER USER
	if (isset($_POST['cent'])) {


		// receive all input values from the form
		$ccb_name = mysqli_real_escape_string($db, $_POST['ccb_name']);
		$rep_name = mysqli_real_escape_string($db, $_POST['rep_name']);
		$contract_name = mysqli_real_escape_string($db, $_POST['contract_name']);
		$buyer_address = mysqli_real_escape_string($db, $_POST['buyer_address']);
		$email = mysqli_real_escape_string($db, $_POST['email']);
		$commodity = mysqli_real_escape_string($db, $_POST['commodity']);
		$price= mysqli_real_escape_string($db, $_POST['price']);
		$quantity= mysqli_real_escape_string($db, $_POST['quantity']);
		$extra_sell_price = mysqli_real_escape_string($db, $_POST['extra_sell_price']);
		$duration = mysqli_real_escape_string($db, $_POST['duration']);
		$operator = mysqli_real_escape_string($db, $_POST['operator']);
		$covered_value= mysqli_real_escape_string($db, $_POST['covered_value']);
		$state = mysqli_real_escape_string($db, $_POST['state']);
	//	$is_offtaker_funded= mysqli_real_escape_string($db, $_POST['is_offtaker_funded']);
		$allow_independent_offtaker= mysqli_real_escape_string($db, $_POST['allow_independent_offtaker']);
		//$pay_commas_derivative = mysqli_real_escape_string($db, $_POST['pay_commas_derivative']);

		// form validation: ensure that the form is correctly filled
		if (empty($ccb_name)) { array_push($errors, "ccb_name is required"); }
		if (empty($rep_name)) { array_push($errors, "rep_name is required"); }
		if (empty($contract_name)) { array_push($errors, "contract_name is required"); }
		if (empty($buyer_address)) { array_push($errors, "buyer_address is required"); }
		if (empty($email)) { array_push($errors, "email is required"); }
		if (empty($commodity)) { array_push($errors, "commodity is required"); }
		if (empty($price)) { array_push($errors, "price is required"); }
		if (empty($quantity)) { array_push($errors, "quantity is required"); }
	  if(!is_numeric($extra_sell_price)) { array_push($errors, "Please ensure you Extra Sell Price is Digits"); }
		if (empty($duration)) { array_push($errors, "duration is required"); }
		if (empty($operator)) { array_push($errors, "operator is required"); }
	 	if(!is_numeric($covered_value)) { array_push($errors, "Please ensure your covered value is Digit"); }
		if (empty($state )) { array_push($errors, "state  is required"); }
	//	if (empty($is_offtaker_funded)) { array_push($errors, "is_offtaker_funded is required"); }
		if (empty($allow_independent_offtaker)) { array_push($errors, "allow_independent_offtaker is required"); }
		//if (empty($pay_commas_derivative)) { array_push($errors, "pay_commas_derivative is required"); }


		$total=$price * $quantity;
				//validation
		if ($covered_value > $total) {
			$errcovered_value = "Sorry Your Covered Value should Not Be greater Than (Unit cost *  Quantity) ";
			   array_push($errors, $errcovered_value);
	   }
	   if ($covered_value < $total) {
		$errcovered_value = "Sorry Your Covered Value should Not Be Less Than (Unit cost *  Quantity) ";
		   array_push($errors, $errcovered_value);
   }

		$price = ($price * 1000000000000000000);
		$priceE = ($price / 1000000000000000000);
		$covered_value = ($covered_value * 1000000000000000000);
		$covered_valueE = ($covered_value / 1000000000000000000);
		$bonded_value = ($bonded_value * 1000000000000000000);

		$extra_sell_price= (($extra_sell_price /100)* 1000000000000000000);
		$extra_sell_priceE= ($extra_sell_price / 1000000000000000000);
		$extra_buy_price= ($extra_buy_price * 1000000000000000000);
		$credit_percent= ($credit_percent * 1000000000000000000);
		$interest_rate= ($interest_rate * 1000000000000000000);
		$gorder_name=$contract_name;

		//if ($password_1 != $password_2) {
			//array_push($errors, "The two passwords do not match");
		//}

		// register user if there are no errors in the form
		if (count($errors) == 0) {
			$gorder_token = getToken($gorder_name, $password);
		 if($gorder_token == "")
			{
					$gorder_token = register($gorder_name, $password, $admin_token);
			}
			if($status==0){

  $gorder_address = getAddress($password, $gorder_token);

  $register_GorderEntity_response = GorderEntity($admin_address, $admin_password, $gorder_address, $buyer_address, $duration, $commodity, $price, $quantity, $covered_value, $bonded_value, $extra_sell_price, $extra_buy_price, $operator, $admin_token);
				sleep(10);
	if(empty($register_GorderEntity_response)){

			echo "Sorry there is something wrong with your first call (Guranteed Order Entity) "."<br />";
	}
	else
	{  //function GorderDetailsEntity($buyer_address, $buyer_password, $gorder_address, $price, $quantity, $covered_value, $bonded_value, $credit_percent, $handle, $allow_independent_offtaker, $is_offtaker_funded, $pay_commas_derivative, $token)

		 $register_GorderDetailsEntity_response = GorderDetailsEntity($admin_address, $gorder_address, $admin_password, $price, $quantity, $covered_value, $bonded_value, $credit_percent, $handle, $allow_independent_offtaker, $is_offtaker_funded, $pay_commas_derivative, $admin_token);
		 sleep(15);
	}if(empty($register_GorderDetailsEntity_response)){

		 echo "Sorry there is something wrong with your second call (Guranteed Details Entity) "."<br />";
 }
 else
 {
	 //function GorderAccountEntity($buyer_address, $buyer_password, $gorder_address, $interest_rate, $token)
	 $register_GorderAccountEntity_response = GorderAccountEntity($admin_address, $admin_password, $gorder_address, $interest_rate, $admin_token);

 }
 if(empty($register_GorderAccountEntity_response)){

		 echo "Sorry there is something wrong with the Third call (Guranteed Account Entity) "."<br />";
 }
 else
 {
	 $price = ($price / 1000000000000000000);
	 $covered_value = ($covered_value / 1000000000000000000);
	 $bonded_value = ($bonded_value / 1000000000000000000);
	 $extra_sell_price= ($extra_sell_price / 1000000000000000000);
	 $extra_buy_price= ($extra_buy_price / 1000000000000000000);
	 $credit_percent= ($credit_percent / 1000000000000000000);
	 $interest_rate= ($interest_rate / 1000000000000000000);
	 $contract_name = $gorder_name;

	 //script to get the last four digit
	 //$digit= $buyer_address;
	 //$lastdigits = substr($digits, -4);


	 //script to get the last four digit
	 $digit= $buyer_address;
	 $no_of_digits=5;
	 $var='';
	 for($i=1; $i<=$no_of_digits; $i++){
	 $var .=rand(0,9);
	 $lastdigits = substr($digit, -4);
	$contract_Id= "CELL/GORDER/ADMIN01/$var/$lastdigits";
	}
	if(!empty($contract_Id)){
	
		$InsertDb = InsertDb('localhost', 'ebube', 'advancegrace', 'agrikorefund', 'smartcontract', $contract_name, $buyer_address, $email, $commodity, $price, $quantity, $extra_sell_price, $extra_buy_price, $duration, $operator, $covered_value, $bonded_value, $state, $handle, $credit_percent, $interest_rate, $is_offtaker_funded, $allow_independent_offtaker, $pay_commas_derivative, $contract_Id, $gorder_address);
		//$success1=" Congratulations Smartcontract Created Successfully,";
		$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'agrikorefund');
		$query = "SELECT * FROM smartcontract WHERE contract_Id='$contract_Id'";
		$results = mysqli_query($db, $query);
		if (mysqli_num_rows($results) == 1){
		$_SESSION['TransactionTokenGorder'] = $contract_Id;
		header("location:./gorderSuccess.php");
//the Email Ends here
			
			}if(!empty($contract_Id)){
				$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'cellulantharry@gmail.com';                 // SMTP username
$mail->Password = 'advancegrace2016';                           // SMTP password
//$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->setFrom('cellulantharry@gmail.com', 'AGRIKORE BLOCKCHAIN SMARTCONTRACT');
$mail->addAddress($email, ' ');     // Add a recipient
//$mail->addAddress('ellen@example.com');               // Name is optional//
//$mail->addReplyTo('info@example.com', 'Information');
//$mail->addBCC('bcc@example.com');

//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'SMART CONTRACT';
$mail->Body    = '<table border="0" cellpadding="0" cellspacing="0" width="100%">  
    <tr>
      <td style="padding: 10px 0 30px 0;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" width="600" style="border: 1px solid #cccccc; border-collapse: collapse;">
          <tr>
            <td align="center" bgcolor="#70bbd9" style="padding: 30px 0 20px 0; color: #153643; font-size: 29px; font-weight: bold; font-family: Arial, sans-serif;">
              <h2 style="font-size:32px">Agrikore</h2>
              <span style="color:#00b15e; font-size:20px">Smart Contract For '.$ccb_name.'</span>  
            </td>
          </tr>
          <tr>
            <td bgcolor="#ffffff" style="padding: 40px 30px 40px 30px;">
              <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                  <td style="color: #153643; font-family: Arial, sans-serif; font-size: 20px;">
                    <b> Dear '.$rep_name.' </b> <span style="float:right; font-size:10px">'.$date. '</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 20px 0 30px 0; color: #153643; font-family: Arial, sans-serif; font-size: 14px; line-height: 20px;">
                  This is to notify that your smart contract have been successfully created and is awaiting approval. Below are the details and terms thereof:<br/>

                  Corporate Commodity Buyer:<span style="margin-left:140px">'. $ccb_name .'</span> <br/>  
                  Corporate Commodity Buyer’s Delivery Address:<span style="margin-left:17px">'. $state.' </span> <br/>
				  Order Size:<span style="margin-left:250px">'.$quantity.' MT</span> <br/>
				  Smartcontract ID:<span style="margin-left:250px">'.$contract_Id.' MT</span> <br/>
                  Creation Date:<span style="margin-left:216px">'.$date.'</span> <br/>
                  Terms of Renewal:<span style="margin-left:204px"> Auto renew @ Expiration / One Off MT</span> <br/>


                  You have also by this electronic order agreed to abide by the Agrikore MarketPlace User License Agreement terms and conditions as follows
    
    <center><h2 style="color: green; font-size: 20px" >MarketPlace User Licence Agreement</h2></center>
    <div style="font-size: 15px; margin-top: 10px">I confirm that I will abide by the terms of Security that I placed on the Smart Contract, I authorise Instant payment from my Wallet for the fulfilment of the order to the Farmer upon delivery of the grain.
      <p>I authorise Cellulant Nigeria Limited To assign third party Offtakers (Aggregators) to facilitate the fulfilment of this Guaranteed order.</p>
      <p>I accept that I will replenish my wallet upon receiving the aggreed quantity of produce. I aggree that I will be charged interest if I fail to meetup with the aggreed contract term. </p>
    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <table border="0" cellpadding="0" cellspacing="0" width="100%">
                      <tr>
                        <td width="260" valign="top">
                           
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td bgcolor="#ee4c50" style="padding: 30px 30px 30px 30px;">
              <table border="0" cellpadding="0" cellspacing="0" width="100%">
                <tr>
                  <td style="color: #ffffff; font-family: Arial, sans-serif; font-size: 14px;" >
                    <center>Powered by <img src="smart101/images/cellulant.jpg" alt="Cellulant" width="100" height="30" style="display: block;" /></center>
                  </td>
                  <td align="right" width="25%">
                    <table border="0" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="font-family: Arial, sans-serif; font-size: 12px; font-weight: bold;">
                          <a href="http://www.twitter.com/" style="color: #ffffff;">
                            <img src="images/tw.gif" alt="Twitter" width="38" height="38" style="display: block;" border="0" />
                          </a>
                        </td>
                        <td style="font-size: 0; line-height: 0;" width="20">&nbsp;</td>
                        <td style="font-family: Arial, sans-serif; font-size: 12px; font-weight: bold;">
                          <a href="http://www.twitter.com/" style="color: #ffffff;">
                            <img src="images/fb.gif" alt="Facebook" width="38" height="38" style="display: block;" border="0" />
                          </a>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>';
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo '';
}


}

 }
}
  }
		}

	}


	
?>