<?php

//include ('fundScript/config.php');
include("configzZ.php");

$return_arr = array();
$phone = $_GET['phone'];
// $role = 'offtaker';

$sql = "SELECT name, clearance_Id, password, status FROM agent_table WHERE  phone = ?";

if($stmt = mysqli_prepare($conn, $sql)){
    // Bind variables to the prepared statement as parameters
    mysqli_stmt_bind_param($stmt, "s", $param_address);

    // Set parameters
    $param_address = $phone;


    // Attempt to execute the prepared statement
    if(mysqli_stmt_execute($stmt)){
        // Store result
        mysqli_stmt_store_result($stmt);

        if(mysqli_stmt_num_rows($stmt) == 1){
            mysqli_stmt_bind_result($stmt, $name, $clearance_Id, $password, $status);
            if(mysqli_stmt_fetch($stmt)){
                $return_arr = array(
                    "name" => $name,
                    "clearance_Id" => $clearance_Id,
                    "password" => $password,
                    "status" => $status,
                );
            }
        }
    }
}

// Close statement
mysqli_stmt_close($stmt);

// Encoding array in JSON format
echo json_encode($return_arr);
