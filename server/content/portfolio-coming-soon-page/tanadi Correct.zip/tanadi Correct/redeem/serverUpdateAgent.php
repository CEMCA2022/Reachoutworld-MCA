<?php
include("functionsF.php");

$errname = "";
$errclearance_Id  = "";
$errpassword_1= "";
$errstatus = "";

// $successMessage="";
// $clearance_Id  = "";
// $password_1 = "";
// $status  = "";
// $phone= "";


$errors = array();
$messages= array();
// $admin_address = "0x2d2d

	// connect to database
	$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');




	// REGISTER USER
	if (isset($_POST['check'])) {

				$phone = mysqli_real_escape_string($db, $_POST['phone']);
				$password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
				$status1 = mysqli_real_escape_string($db, $_POST['status']);

				if (empty($password_1)) { array_push($errors, "Please Enter a password"); }
				if(strlen($password_1) < 8){
				$errpassword_1 = '<p class="errText">Please Agent Password should be Minimum of 8 Characters</p>';
				array_push($errors, $errpassword_1);}
    $password_1 = md5($password_1);

		// register user if there are no errors in the form
		if (count($errors) == 0) {


			            updateAgentT('localhost', 'ebube', 'advancegrace', 'tanadi', 'agent_table',$row_id, $status1, $password_1, $phone);
															$messagesSuccess = "Congratulations! Agent Record Updated Successfully";


							}


}


?>
