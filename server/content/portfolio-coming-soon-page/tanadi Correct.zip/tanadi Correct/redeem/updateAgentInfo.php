<?php

 include('serverUpdateAgent.php');


 ?>


<!DOCTYPE html>
<html>
<head>
<title>Tanadi Discount Sales| Agent Update</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font -->
<link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">


      <link rel="stylesheet" href="stylea.css">
      <link rel="stylesheet" href="css/style33.css">
      <link rel="stylesheet" type="text/css" href="css2/prompt.css">
      <link rel="stylesheet" href="cssLoader/styleLoader2.css">
      	<link rel="stylesheet" type="text/css" href="css/promptz.css">



 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js">
</script>
<script src="jquery-1.8.3.js"></script>
<style>
#btn-submi:disabled{padding: 10px 20px;background: #CCC;border: 0;color: #FFF;display:inline-block;margin-top:20px;cursor: no-drop;}
.validation-error {color:#FF0000;}
.input-control{padding:10px;}
.input-group{margin-top:10px;}
</style>


<script>


$(document).ready(function(){
	$('#btn-submit').click(function() {
     $('#logo').hide();
    //$('#btn-submit').attr("disabled",true).delay(13000);
	 $('#loader1').fadeIn('slow', function(){
     $('#loader1').delay(3000).fadeOut("slow");
		  $('#loader2').delay(3500).fadeIn("slow");
      $('#loader2').delay(10000).fadeOut("slow");
      $('#logo').delay(50000).fadeIn("slow");


	 });
 });
});
</script>
<style>
        .error {color: red;
        font-size:12px;}
     </style>
<!-- //web font -->
</head>
<body>
	<!-- main -->
  <div class="main-w3layouts wrapper" style="margin-top:-10px">



  <div id="logo" >

		<!-- <center><img src="images/Agrikore.png" style="width: 100px; height: 25px"></center> -->
		<h1 style="font-size:20px">TANADI DISCOUNT SALES </h1>
    <center><p style="font-size:10px; color:white">REDEEMTION</p></center>
    <center> <?php echo "<div id=\"promptRed\">".$messagesSuccess."</div>"; ?></center>
    <center> <?php echo "<div id=\"promptBlack\">".$messagesError."</div>"; ?></center>
    <center> <?php echo "<div id=\"promptBlack\">".$erragent_name."</div>"; ?></center>


    </div>
    <div id="loader1" style="margin-top:-30px; display:none">
    <center>  <div class="word" style="color:white">BLOCKCHAIN &nbsp PROCESSING</div></center>

        </div>
        <div id="loader2" style="margin-top:-20px;display:none ">
          <center><div class="word" style="color:white">DATA&nbspVERIFICATION&nbspENCRYPTION</div></center>

            </div>

      </center>
    </div>
		<div class="main-agileinfo" style="margin-top:-13px">
			<div class="agileits-top">
			<form  action="updateAgentInfo.php"  method="post">

          <label class="label" >MOBILE NUMBER</label>
					<input class="text" type="text"  id="phone" name="phone"  placeholder="Enter your Wallet Number e.g: XXXX / XXX / XXXX" value="<?php echo $phone; ?>"  required="" >
					<span class = "error"><?php echo $errphone;?></span>
          <label class="label" >NAME</label>
					<input class="text" disabled type="text" name="name" placeholder="name" id="name" value="<?php echo $name; ?>"  required="" >
          <label class="label" >CLEARANCE-ID</label>
					<input class="text" type="text" name="clearance_Id" disabled id="clearance_Id" placeholder="CLEARANCE ID" value="<?php echo $clearance_Id; ?>" required   >
          <span class = "error"> <?php echo $errclearance_Id;?></span>
          <label class="label" >PASSWORD</label>
					<input class="text" type="text" name="password_1"  id="password" placeholder="Password" value="<?php echo $password_1; ?>" required   >
          <span class = "error"> <?php echo $errpassword_1?></span>
          <label class="label" >STATUS</label>
					<input class="text" type="text"  id="status" name="status" placeholder=" Login Status" value="<?php echo $status; ?>"  required="" >
          <span class = "error"><?php echo $errstatus;?></span>

					<input type="submit" value="UPDATE" id="btn-submi" name="check" style="background-color: rgb(135,192,100); border:0px">

       <input type="submit"  value="Click here to Cancel or  Return back!" style="font-size:10px ; background-color:transparent; border-style:none; margin-bottom:-20px; margin-top:-20px">
				</form>


			</div>
		</div>
		<!-- copyright -->
		<div class="colorlibcopy-agile">
			<p>© 2020 Tanadi Discount Sales All rights reserved | Powered by Tanadi <a href="" target="_blank"></a></p>
    </div>
      <script src="http://code.jquery.com/jquery-1.10.2.js"></script>



    <script src="jsLoader/index.js"></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/lettering.js/0.6.1/jquery.lettering.min.js'></script>

      <script src="js/index.js"></script>
</body>
</html>

<script>
		$('#phone').bind('change paste keyup', function(){
			let current_address = $(this).val();
			if(current_address !== "")
			{
				$.ajax({
					url: "agentInfo.php",
					type: "get",
					data: { phone: current_address },
					success: function(data){
						var response = JSON.parse(data);
						if(response.name != undefined)
						{
							$("#name").val(response.name);
							$("#clearance_Id").val(response.clearance_Id);
							$("#password").val(response.password);
       $("#status").val(response.status);
						}
						else
						{
							$("#name").val("");
							$("#clearance_Id").val("");
							$("#password").val("");
							$("#status").val("");
						}
					},
					error: function(response){
      $("#name").val("");
      $("#clearance_Id").val("");
      $("#password").val("");
      $("#status").val("");
					}
				});
			}
			else
			{
    $("#name").val("");
    $("#clearance_Id").val("");
    $("#password").val("");
    $("#status").val("");
			}
		});
	</script>
