<?php
	include("functionsG.php");
	session_start();
	// variable declaration
	$username = "";
	$buyer_name = "";
	$location = "";
	$errors = array();
	$messages= array();
	$_SESSION['success'] = "";
	$admin_address = "0x2d2d8721fcacb58c7f5f2946bdcc487629da2d64";
	$admin_token = getToken('admin', 'Agrikore8546&');

  $db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'agrikorefund');
	$buyer = fetchFromDatabase('localhost', 'ebube', 'advancegrace', 'agrikorefund', 'smartcontract');

	// connect to database
	// REGISTER USER
	if (isset($_POST['assign2'])) {

		// receive all input values from the form
		$gorder_address = mysqli_real_escape_string($db, $_POST['gorder_address']);
		$address = mysqli_real_escape_string($db, $_POST['address']);

		// form validation: ensure that the form is correctly filled
	  if (empty($gorder_address)) { array_push($errors, "gorder address is required"); }
		if (empty($address)) { array_push($errors, "address is required"); }
		if ($errPrompt1) { array_push($errors,$errPrompt1); }
		if ($errPrompt1b) { array_push($errors,$errPrompt1b); }
		if ($errPrompt2) { array_push($errors,$errPrompt2); }




		// register user if there are no errors in the form
		if (count($errors) == 0) {

			$result = mysqli_query($db, "SELECT * FROM smartcontract WHERE gorder_address='" . $_POST['gorder_address'] . "'");
		$row = $result->fetch_assoc();
		$test= $row['mula'];
		$status= $row['status'];
		$contract_Id= $row['contract_Id'];


		$result = mysqli_query($db, "SELECT offtaker FROM gorderOfftaker WHERE gorder_address='" . $_POST['gorder_address'] . "'");
	$row = $result->fetch_assoc();
	$offtaker= $row['offtaker'];

     $check=mysqli_query($db,"select * from gorderOfftaker WHERE gorder_address='$gorder_address' and offtaker='$address'");
     $checkrows=mysqli_num_rows($check);


	$admin_token = getToken('admin', 'Agrikore8546&');



		if($status != "1"){
			$errPrompt1 = "SORRY THE SELECTED SMARTCONTRACT IS NOT APPROVED!";
			$errPrompt1b = "PLEASE APPROVE BEFORE ASSIGNING OFFTAKER";
		}else{

			    if($checkrows>0) {
						$errPrompt2 = "SORRY THE OFFTAKER HAS ALREADY BEEN ASSIGNED TO THIS CONTRACT!";
			    } else {
						{
						      $register_AssignOfftaker_response = AssignOfftaker($admin_address, "agrikore", $gorder_address, $address, $admin_token);

						    if(empty($register_AssignOfftaker_response)){
						        $success2 = "Sorry there is a problem with your First call: Assign offtaker / CHECK YOUR SERVER FOR TOKEN";
						    }else{
									$TransactionHash = $register_AssignOfftaker_response;
						      InsertOfftaker2Gorder('localhost', 'ebube', 'advancegrace', 'agrikorefund', 'gorderOfftaker', $gorder_address, $contract_Id, $address,$TransactionHash);
									$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'agrikorefund');


									$query = "SELECT * FROM gorderOfftaker WHERE TransactionHash='$TransactionHash'";
									$results = mysqli_query($db, $query);
 
									if (mysqli_num_rows($results) == 1)
									 {
									 $_SESSION['TransactionHashAss'] = $TransactionHash;
									header("Location:AssignOfftaker2GorderSuccess.php");
 }
						    }
						  }
			     }

	  }
		}
	}
?>
