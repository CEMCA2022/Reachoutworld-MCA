<?php


// This is the Function to fetch from Database
// function fetchFromDatabase($host, $user, $password, $database, $table)
// {
//     $conn = mysqli_connect($host, $user, $password, $database);
//     if(!$conn)
//     {
//         die("Could not connect: ".mysqli_connect_error());
//     }
//
//     $query = "select * from $table";
//     $output = array();
//     if($result = mysqli_query($conn, $query))
//     {
//         while($r = mysqli_fetch_assoc($result))
//         {
//             array_push($output, $r);
//         }
//     }
//     else
//     {
//         $err = mysqli_error($conn);
//         mysqli_close($conn);
//         die("SQL Error: $err\r\n");
//     }
//
//     return $output;
// }


// this is the Update status function Mula reserve balance
function updateAddressStatusM($host, $user, $password, $database, $table, $row_id, $MulaReserveBalance)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set MulaReserveBalance='$MulaReserveBalance' , status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}


// This is the function to update the CCB ledger
function updateAddressStatusCCBledger($host, $user, $password, $database, $table, $row_id)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
       echo "Record updated successfully";
    } else {
       echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

//  This  is the function to update the CCB Equivalent Mula
function updateAddressStatusCCBledgerMula($host, $user, $password, $database, $table, $amount, $row_id)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set CCB_MULA='$amount', CCBbalance =' ', status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}


//  This  is the function to update the general_ledger
function updateOrderTable($host, $user, $password, $database, $table, $redeem_quantity, $redeem_code, $agent_name)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

  //  $sql = "update $table set mula= mula + '$mulaIN', where address=$address";
    $sql = "update $table set redeem_quantity= '$redeem_quantity',agent_name= '$agent_name', status=1 where redeem_code='$redeem_code'";
    if ($conn->query($sql) === TRUE) {
       // echo "Order Redeemed Successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}


// This is where we Update the CCB_ledger Database with id  username and Address

function updateAgentT($host, $user, $password, $database, $table, $row_id, $status1, $password_1, $phone)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set status='$status1', password='$password_1' where phone='$phone'";
    if ($conn->query($sql) === TRUE) {
      // echo "Agent Fields updated successfully";

    } else {
      //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}





//  This  is the function to update the general_ledger
function updateBuyerGeneralLedgerNaira($host, $user, $password, $database, $table, $naira, $address)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

  //  $sql = "update $table set mula= mula + '$mulaIN', where address=$address";
    $sql = "update $table set naira= naira + '$naira' where address='$address' ";
    if ($conn->query($sql) === TRUE) {
      //  echo "Record updated successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}



//  This  is the function to update the Offtaker Equivalent Mula
function updateAddressStatusOfftakerledgerMula($host, $user, $password, $database, $table, $amount, $row_id)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set OFFTAKER_MULA='$amount', offtaker_balance =' ', status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}




// This is the function to update the Offtaker ledger
function updateAddressStatusOfftakerledger($host, $user, $password, $database, $table, $row_id)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}


// this is the Update status function Naira reserve balance
function updateAddressStatusN($host, $user, $password, $database, $table, $row_id, $NairaReserveBalance)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set NairaReserveBalance='$NairaReserveBalance' , status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

// InsertGorderLedger('localhost', 'root', '', 'agrikorefund', 'gorder_ledger',  $username, $password1, $buyer_address, $CCB_name);
//This is the function to insert into the Guarranteed order Approval Database
function InsertToRedemptionTable($host, $user, $password, $database, $table, $name1, $phone1, $redeem_quantity, $redeem_code,$agent_name, $amount, $size1)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set name='$name1',phone= '$phone1', redeem_quantity= '$redeem_quantity', redeem_code= '$redeem_code', agent_name= '$agent_name', amount='$amount', size='$size1'";
    if ($conn->query($sql) === TRUE) {
       //echo "Record inserted successfully into redemption table";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

function updateOrderTableWithDate($host, $user, $password, $database, $table,  $redeem_date, $redeem_code)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set redemption_date='$redeem_date' where redeem_code='$redeem_code'";
    if ($conn->query($sql) === TRUE) {
       // echo "Reeem Date updated successfully";
    } else {
        //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
// InsertGorderLedger('localhost', 'root', '', 'agrikorefund', 'gorder_ledger',  $username, $password1, $buyer_address, $CCB_name);
//This is the function to insert into the Guarranteed order Approval Database
function InsertGorderLedger($host, $user, $password, $database, $table, $username, $password1, $buyer_address, $amount)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set buyer_username'$username', buyer_password= '$password1', buyer_address= '$buyer_address', CCB_MULA= '$amount'";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
//This is the function to insert into the Guarranteed order Approval Database
function InsertTransaction($host, $user, $password, $database, $table, $initiator, $wallet, $amount,$userAddress,$channel, $TransactionToken)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set initiator='$initiator', towallet= '$wallet', amount= '$amount', userAddress='$userAddress', channel='$channel', TransactionToken='$TransactionToken'";
    if ($conn->query($sql) === TRUE) {
        //echo "Record updated successfully";
    } else {
       // echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
