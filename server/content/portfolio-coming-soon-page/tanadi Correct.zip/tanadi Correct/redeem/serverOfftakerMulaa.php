<?php
error_reporting(0);
// variable declaration
include("functionsF.php");


	$name="";
	$phone="";
	$quantity="";
	$address="";
	$size="";
	$redeem_code="";
	$redeem_quantity="";
	$amount="";

	$errname="";
	$errphone="";
	$errquantity="";
	$erraddress="";
	$errsize="";
	$erredeem_code="";
	$errredeem_quantity="";
	$erramount="";

	$status=0;
	$errors = array();
	$messages= array();
	$_SESSION['success'] = "";



	// connect to database
	$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');

	// REGISTER USER
	if (isset($_POST['redeem'])) {

		// receive all input values from the form


		if(empty($_SESSION['clearance_Id'])) {
					$erragent_name = "Sorry you are not an Agent (Only for Tanadi Agent)";
						array_push($errors, $erragent_name);
		}

		$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');
		$result = mysqli_query($db, "SELECT * FROM agent_table WHERE clearance_Id = '" . $_SESSION['clearance_Id'] . "'");
		$row = $result->fetch_assoc();

		$agent_name= $row['name'];



		$redeem_quantity= mysqli_real_escape_string($db, $_POST['redeem_quantity']);
		$phone= mysqli_real_escape_string($db, $_POST['phone']);
		$amount= mysqli_real_escape_string($db, $_POST['amount']);
		$redeem_code= mysqli_real_escape_string($db, $_POST['redeem_code']);
		$size= mysqli_real_escape_string($db, $_POST['size']);


		$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');
		$check = mysqli_query($db, "SELECT name,quantity, status, address FROM order_table WHERE  redeem_code='$redeem_code'");
		$row = $check->fetch_assoc();
		 $quantity1 = $row['quantity'];
			 $stausCode= $row['status'];

		// $userAddress = $row['userAddress'];
		if($redeem_quantity > $quantity1){
			$errredeem_quantity='<p>Please Your Redeem Quantity is Greater that your Quantity</p>';
			array_push($errors, $errredeem_quantity);
		}



		// form validation: ensure that the form is correctly filled

		// register user if there are no errors in the form
		if (count($errors) == 0) {

			    if($stausCode == 0)

					{
			            updateOrderTable('localhost', 'ebube', 'advancegrace', 'tanadi', 'order_table', $redeem_quantity, $redeem_code, $agent_name);
															$messagesSuccess = "Congratulations! Order REDEEMED Successfully";
															$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');
															$check = mysqli_query($db, "SELECT name,phone, size FROM order_table WHERE  redeem_code='$redeem_code'");
															$row = $check->fetch_assoc();
																$name1 = $row['name'];
																	$phone1= $row['phone'];
																	$size1= $row['size'];


															InsertToRedemptionTable('localhost', 'ebube', 'advancegrace', 'tanadi', 'redemption_table', $name1, $phone1,$redeem_quantity, $redeem_code, $agent_name,$amount,$size1);
															$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');
															sleep(5);
															$check = mysqli_query($db, "SELECT redeem_date FROM redemption_table WHERE  redeem_code='$redeem_code'");
															$row = $check->fetch_assoc();
																$redeem_date = $row['redeem_date'];

 														updateOrderTableWithDate('localhost', 'ebube', 'advancegrace', 'tanadi', 'order_table', $redeem_date, $redeem_code);

							}else{
									$messagesError = "Sorry this Redeemtion Order Code has been REDEEMED (no longer valid)";
							}


				}
}


?>
