<?php
$host = "localhost";
$userName = "ebube";
$password = "advancegrace";
$dbName = "agrikorefund";

// Create database connection
$conn = new mysqli($host, $userName, $password, $dbName);

// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
?>