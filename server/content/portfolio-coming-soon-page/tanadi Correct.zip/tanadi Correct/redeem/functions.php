<?php

    function UpdateOperator($admin_address, $admin_password, $operator_address, $operator_name, $location, $fixed_rate, $percentage_rate, $token)
{
  $curl = curl_init();

      $parameter = curl_escape($curl,'{"op":"updateoperator", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$operator_address.'", "name":"'.$operator_name.'", "loc":"'.$location.'","fixrate":"'.$fixed_rate.'","percentrate":"'.$percentage_rate.'"}');

  curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/operator/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));


        $result = curl_exec($curl);
        $array_response = json_decode($result, true);

        if (curl_error($curl)) {
            $error_msg = curl_error($curl);
        }
        curl_close($curl);

        if (isset($error_msg)) {
            // TODO - Handle cURL error accordingly
          //  echo($error_msg);
        }

        return $array_response;
    }

    function UpdateLogistic($admin_address, $admin_password, $logistic_address, $logistic_name, $location, $fixed_rate, $percentage_rate, $token)
{
  $curl = curl_init();

      $parameter = curl_escape($curl,'{"op":"updatelogistics", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$logistic_address.'", "name":"'.$logistic_name.'", "loc":"'.$location.'","fixrate":"'.$fixed_rate.'","percentrate":"'.$percentage_rate.'"}');

  curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/logistics/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));


        $result = curl_exec($curl);
        $array_response = json_decode($result, true);

        if (curl_error($curl)) {
            $error_msg = curl_error($curl);
        }
        curl_close($curl);

        if (isset($error_msg)) {
            // TODO - Handle cURL error accordingly
          //  echo($error_msg);
        }

        return $array_response;
    }


    function UpdateBuyer($admin_address, $admin_password, $buyer_address, $buyer_name, $location, $token)
    {
        $curl = curl_init();

        $parameter = curl_escape($curl,'{"op":"updatebuyer", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$buyer_address.'", "name":"'.$buyer_name.'", "loc":"'.$location.'"}');

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://www.agrikore.net/buyer/unsafe/ad/'.$parameter,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_HTTPHEADER => array(
                "x-access-token: $token"
            ),
        ));


        $result = curl_exec($curl);
        $array_response = json_decode($result, true);

        if (curl_error($curl)) {
            $error_msg = curl_error($curl);
        }
        curl_close($curl);

        if (isset($error_msg)) {
            // TODO - Handle cURL error accordingly
          //  echo($error_msg);
        }

        return $array_response;
    }

    function UpdateLoaner($admin_address, $admin_password, $loaner_address, $loanername, $location, $token)
    {
        $curl = curl_init();

        $parameter = curl_escape($curl,'{"op":"updateloaner", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$loaner_address.'", "name":"'.$loaner_name.'", "loc":"'.$location.'"}');

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://www.agrikore.net/loaner/unsafe/ad/'.$parameter,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_HTTPHEADER => array(
                "x-access-token: $token"
            ),
        ));


        $result = curl_exec($curl);
        $array_response = json_decode($result, true);

        if (curl_error($curl)) {
            $error_msg = curl_error($curl);
        }
        curl_close($curl);

        if (isset($error_msg)) {
            // TODO - Handle cURL error accordingly
          //  echo($error_msg);
        }

        return $array_response;
    }




function fetchFromDatabase($host, $user, $password, $database, $table)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $query = "select * from $table";
    $output = array();
    if($result = mysqli_query($conn, $query))
    {
        while($r = mysqli_fetch_assoc($result))
        {
            array_push($output, $r);
        }
    }
    else
    {
        $err = mysqli_error($conn);
        mysqli_close($conn);
        die("SQL Error: $err\r\n");
    }

    return $output;
}


function addBuyer($admin_address, $admin_password, $buyer_address, $buyer_name, $location, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"addbuyer", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$buyer_address.'", "name":"'.$buyer_name.'", "loc":"'.$location.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/buyer/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));


    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
      //  echo($error_msg);
    }

    return $array_response;
}

function addOperator($admin_address, $admin_password, $operator_address, $operator_name, $location, $fixed_rate, $percentage_rate, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"addoperator", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$operator_address.'", "name":"'.$operator_name.'", "loc":"'.$location.'","fixrate":"'.$fixed_rate.'","percentrate":"'.$percentage_rate.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/operator/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);
    return $array_response;
}



function addLogistic($admin_address, $admin_password, $logistic_address, $logistic_name, $location, $fixed_rate, $percentage_rate, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"addlogistics", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$logistic_address.'", "name":"'.$logistic_name.'", "loc":"'.$location.'","fixrate":"'.$fixed_rate.'","percentrate":"'.$percentage_rate.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/logistics/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);
    return $array_response;
}

function addCertifier($admin_address, $admin_password, $certifier_address, $certifier_name, $location, $comm, $fixed_rate, $percentage_rate, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"addcertifier", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$certifier_address.'", "name":"'.$certifier_name.'", "loc":"'.$location.'","comm":"'.$comm.'","fixrate":"'.$fixed_rate.'","percentrate":"'.$percentage_rate.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/certifier/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);
    return $array_response;

}


function addLoaner($admin_address, $admin_password, $loaner_address, $loaner_name, $loaner_loc, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"addloaner", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$loaner_address.'", "name":"'.$loaner_name.'", "loc":"'.$loaner_loc.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/loaner/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));


    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
      //  echo($error_msg);
    }

    return $array_response;
}
// This is the function to update status
function updateAddressStatus($host, $user, $password, $database, $table, $row_id, $address)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set address='$address', status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}




// This is the function I use to dump the $farmer_address and $farmer_name to the  farmer_ledger
function InsertUser($host, $user, $password, $database, $table, $name, $quantity, $phone, $address, $redeem_code)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set name='$name', quantity='$quantity', phone='$phone', address='$address', redeem_code='$redeem_code'";
    if ($conn->query($sql) === TRUE) {
       //echo "New Order Created successfully Thank You";
    } else {
      // echo "Error updating Order: " . $conn->error;
    }

    $conn->close();
}

// This is the function I use to dump the $farmer_address and $farmer_name to the  farmer_ledger
function UpdateFarmerNew($host, $user, $password, $database, $table, $farmer_name, $location, $wallet, $state)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set farmer_name='$farmer_name', location='$location', state='$state' where wallet='$wallet'";
    if ($conn->query($sql) === TRUE) {
        //echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

// This is the function I use to dump the $farmer_address and $farmer_name to the  farmer_ledger
function UpdateBuyerNew($host, $user, $password, $database, $table, $buyer_name, $location, $wallet, $state)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set buyer_name='$buyer_name', location='$location', state='$state' where wallet='$wallet'";
    if ($conn->query($sql) === TRUE) {
        //echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

// This is the function I use to dump the $farmer_address and $farmer_name to the  farmer_ledger
function UpdateLoanerNew($host, $user, $password, $database, $table, $loaner_name, $location, $wallet, $state)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set loaner_name='$loaner_name', loaner_loc='$location', state='$state' where wallet='$wallet'";
    if ($conn->query($sql) === TRUE) {
       // echo "Record inserted successfully";
    } else {
       // echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

// This is the function I use to dump the Offtaker Infor
function UpdateOfftakerNew($host, $user, $password, $database, $table, $offtaker_name, $location, $receipt_limit, $fixed_rate, $percentage_rate,$state, $wallet)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set offtaker_name='$offtaker_name', location='$location', state='$state', receipt_limit='$receipt_limit', percentage_rate='$percentage_rate', fixed_rate='$fixed_rate' where wallet='$wallet'";
    if ($conn->query($sql) === TRUE) {
        //echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}


// This is the function I use to dump the Certifier Infor
function UpdateCertifierNew($host, $user, $password, $database, $table, $certifier_name, $location, $comm, $fixed_rate, $percentage_rate,$state, $wallet)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set certifier_name='$certifier_name', location='$location', state='$state', comm='$comm', percentage_rate='$percentage_rate', fixed_rate='$fixed_rate' where wallet='$wallet'";
    if ($conn->query($sql) === TRUE) {
       // echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}



// This is the function I use to dump the Offtaker Infor
function UpdateOperatorNew($host, $user, $password, $database, $table, $operator_name, $location,$fixed_rate, $percentage_rate,$state, $wallet)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set operator_name='$operator_name', location='$location', state='$state', percentage_rate='$percentage_rate', fixed_rate='$fixed_rate' where wallet='$wallet'";
    if ($conn->query($sql) === TRUE) {
        //echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

// This is the function I use to dump the Offtaker Infor
function UpdateLogisticNew($host, $user, $password, $database, $table, $logistic_name, $location,$fixed_rate, $percentage_rate,$state, $wallet)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set logistic_name='$logistic_name', location='$location', state='$state', percentage_rate='$percentage_rate', fixed_rate='$fixed_rate' where wallet='$wallet'";
    if ($conn->query($sql) === TRUE) {
        //echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}



// This is the function I use to dump the $farmer_address and $farmer_name to the  farmer_ledger
function UpdateGenLedgerNew($host, $user, $password, $database, $table, $name, $location, $wallet, $state)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set name='$name', location='$location', state='$state' where wallet='$wallet'";
    if ($conn->query($sql) === TRUE) {
      //  echo "Record inserted successfully";
    } else {
     // echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
// This is the function I use to dump Buyer data /details to the database
function InsertBuyer($host, $user, $password, $database, $table, $username, $password_1, $buyer_name, $location, $buyer_address, $state, $wallet, $userAddress, $status)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set username='$username', password='$password_1', buyer_name='$buyer_name', location='$location', address='$buyer_address', state='$state', wallet='$wallet', userAddress='$userAddress', status='$status'";
    if ($conn->query($sql) === TRUE) {
        //echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

// This is the function I use to dump the Offtaker detail to the database
function InsertOfftakerZ($host, $user, $password, $database, $table, $username, $password_1, $offtaker_name, $location, $offtaker_address, $receipt_limit, $percentage_rate, $fixed_rate,$state, $wallet, $userAddress, $status)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set username='$username', password='$password_1', offtaker_name='$offtaker_name', location='$location', address='$offtaker_address', receipt_limit='$receipt_limit', percentage_rate='$percentage_rate', fixed_rate='$fixed_rate',state='$state', wallet='$wallet', userAddress='$userAddress', status='$status'";
    if ($conn->query($sql) === TRUE) {
        //echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

// This is the function I use to dump the loaners data to the database
function InsertLoanerZ($host, $user, $password, $database, $table, $username, $password_1, $loaner_name, $location, $loaner_address, $state, $wallet, $userAddress, $status)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set username='$username', password='$password_1', loaner_name='$loaner_name', loaner_loc='$location', address='$loaner_address', state='$state', wallet='$wallet',userAddress='$userAddress', status='$status'";
    if ($conn->query($sql) === TRUE) {
      // echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}


// This is the function I use to dump the Operator detail to the database
function InsertOperatorZ($host, $user, $password, $database, $table, $username, $password_1, $operator_name, $location, $operator_address, $percentage_rate, $fixed_rate,$state, $wallet, $userAddress, $status)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set username='$username', password='$password_1', operator_name='$operator_name', location='$location', address='$operator_address', percentage_rate='$percentage_rate', fixed_rate='$fixed_rate',state='$state', wallet='$wallet', userAddress='$userAddress', status='$status'";
    if ($conn->query($sql) === TRUE) {
      //  echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

// This is the function I use to dump the Operator detail to the database
function InsertLogisticZ($host, $user, $password, $database, $table, $username, $password_1, $logistic_name, $location, $logistic_address, $percentage_rate, $fixed_rate,$state, $wallet, $userAddress, $status)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set username='$username', password='$password_1', logistic_name='$logistic_name', location='$location', address='$logistic_address', percentage_rate='$percentage_rate', fixed_rate='$fixed_rate',state='$state', wallet='$wallet', userAddress='$userAddress', status='$status'";
    if ($conn->query($sql) === TRUE) {
      // echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}




// This is the function I use to dump the Offtaker detail to the database
function InsertCertifierZ($host, $user, $password, $database, $table, $username, $password_1, $certifier_name, $location, $certifier_address, $commodity, $percentage_rate, $fixed_rate, $state, $wallet, $userAddress, $status)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set username='$username', password='$password_1', certifier_name='$certifier_name', location='$location', address='$certifier_address', comm='$commodity', percentage_rate='$percentage_rate', fixed_rate='$fixed_rate', state='$state', wallet='$wallet', userAddress='$userAddress', status='$status'";
    if ($conn->query($sql) === TRUE) {
        //echo "Record inserted successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}


// This is the function I use to dump the $farmer Details to the General ledger
function InsertGenLedger($host, $user, $password, $database, $table, $name, $address, $location,$state,$wallet,$userAddress, $role)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set name='$name', location='$location', address='$address',state='$state',wallet='$wallet', userAddress='$userAddress', role='$role'";
    if ($conn->query($sql) === TRUE) {
       //echo "Record inserted successfully";
    } else {
        //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}




// This is the function I use to dump the $Offtaker_address and $offtaker_name to the  offtaker_ledger
function InsertOfftaker($host, $user, $password, $database, $table, $offtaker_address, $offtaker_name )
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set address='$offtaker_address', username= '$offtaker_name'";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}


//This is the function to insert into the Gorder1 table

function InsertCCB_gorder1($host, $user, $password, $database, $table, $username, $buyer_name, $password1, $buyer_address)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set buyer_name= '$buyer_name', buyer_username= '$username', buyer_address='$buyer_address', buyer_password= '$password1'" ;
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

// This is the function I use to dump the $buyer_address and $CCB_name to the  CCB_ledger
function InsertCCB($host, $user, $password, $database, $table, $buyer_address, $CCB_name )
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set address='$buyer_address', username= '$CCB_name'";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

// // This is the function I use to dump the $buyer_address and $CCB_name to the  CCB_ledger
// function InsertOfftaker($host, $user, $password, $database, $table, $offtaker_address, $offtaker_name )
// {
//     $conn = mysqli_connect($host, $user, $password, $database);
//     if(!$conn)
//     {
//         die("Could not connect: ".mysqli_connect_error());
//     }

//     $sql = "insert $table set address='$offtaker_address', username= '$offtaker_name'";
//     if ($conn->query($sql) === TRUE) {
//         echo "Record updated successfully";
//     } else {
//         echo "Error updating record: " . $conn->error;
//     }

//     $conn->close();
// }



//This script will update the operator in some othe Ledger
// This is the function I use to dump the $buyer_address and $CCB_name to the  CCB_ledger
function InsertOperator1($host, $user, $password, $database, $table, $operator_address )
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set operator_address='$operator_address'";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}




// This is where we Update the CCB_ledger Database with id  username and Address
function updateAgentStatusLogin($host, $user, $password, $database, $table, $clearance_Id)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set  status=1 where clearance_Id='$clearance_Id'";
    if ($conn->query($sql) === TRUE) {
       // echo "Agent Status updated successfully";

    } else {
       // echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}



function updateAgentStatusLogout($host, $user, $password, $database, $table, $clearance_Id)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set  status=0 where clearance_Id='$clearance_Id'";
    if ($conn->query($sql) === TRUE) {
       // echo "Agent Status updated successfully";

    } else {
       // echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
// Test Registration

// $admin_address = getAddress('Agrikore8546&', getToken('admin', 'Agrikore8546&'));

// // Start loop here for multiple registration
// $farmer_token = getToken('ecj4real', '11111111');
// $farmer_address = getAddress('11111111', $farmer_token);




// This is the function I use to dump the Operator detail to the database
function InsertDb($host, $user, $password, $database, $table, $contract_name, $buyer_address, $email, $commodity, $price, $quantity, $extra_sell_price, $extra_buy_price, $duration, $operator, $covered_value, $bonded_value, $state, $handle, $credit_percent, $interest_rate, $is_offtaker_funded, $allow_independent_offtaker, $pay_commas_derivative,$contract_Id)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set contract_name='$contract_name', buyer_address='$buyer_address', email='$email', commodity='$commodity', price='$price', quantity='$quantity', extra_sell_price='$extra_sell_price', extra_buy_price='$extra_buy_price', duration='$duration', operator='$operator', covered_value='$covered_value', bonded_value='$bonded_value', state='$state', handle='$handle', credit_percent='$credit_percent', interest_rate='$interest_rate', is_offtaker_funded='$is_offtaker_funded', allow_independent_offtaker='$allow_independent_offtaker', pay_commas_derivative='$pay_commas_derivative', contract_ID='$contract_Id'";
    if ($conn->query($sql) === TRUE) {
      //echo "Record inserted successfully";
    }else{
      // echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

function Random($contract_Id){

  $no_of_digits=5;
  $var='';
  for($i=1; $i<=$no_of_digits; $i++){
  $var .=rand(0,9);
  $contract_ID ="CELL/GORDER/BEANS/$var";
  }


}

// $register_farmer_response = addFarmer($admin_address, 'Agrikore8546&', $farmer_address, 'ECJ4REAL', '1', $farmer_token);

// echo '<pre>'; print_r($register_farmer_response); echo '</pre>';

// $token = getToken('admin', 'Agrikore8546&');
// echo(register('ecj4real', '11111111', $token));
// $token = getToken('admin', 'Agrikore8546&');
// echo '<pre>'; print_r(keystore('11111111',$token)); echo '</pre>';
