<?php include('../smartcontract/servertest1.php') ?>
<!DOCTYPE html>
<html>
<head>
<title>Agrikore | Blockchain</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font -->
<link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">


      <link rel="stylesheet" href="stylea.css">
      <link rel="stylesheet" href="css/style33.css">
      <link rel="stylesheet" type="text/css" href="css2/prompt.css">
      <link rel="stylesheet" href="cssLoader/styleLoader2.css">
      	<link rel="stylesheet" type="text/css" href="css/prompt1.css">
        <link rel="stylesheet" type="text/css" href="css7/style.css">



 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js">
</script>
<script src="jquery-1.8.3.js"></script>
<style>
#btn-submi:disabled{padding: 10px 20px;background: #CCC;border: 0;color: #FFF;display:inline-block;margin-top:20px;cursor: no-drop;}
.validation-error {color:#FF0000;}
.input-control{padding:10px;}
.input-group{margin-top:10px;}
</style>


<script>


$(document).ready(function(){
	$('#btn-submi').click(function() {
     $('#logo').hide();
    //$('#btn-submit').attr("disabled",true).delay(13000);
	 $('#loader1').fadeIn('slow', function(){
     $('#loader1').delay(3000).fadeOut("slow");
		  $('#loader2').delay(3500).fadeIn("slow");
      $('#loader2').delay(10000).fadeOut("slow");
      $('#logo').delay(50000).fadeIn("slow");


	 });
 });
});
</script>
<style>
        .error {color: #FF0000;
        font-size:12px;}
     </style>
<!-- //web font -->
</head>
<body>
	<!-- main -->
  <div class="main-w3layouts wrapper" style="margin-top:-10px">


            <div style="margin-bottom:-20px;font-size:8px; color:red; margin-top:2px">


                                    
            </div>
  <div id="logo" >
		<center><img src="images/Agrikore.png" style="width: 100px; height: 25px"></center>
		<h1 style="font-size:20px">SmartContract</h1>
    </div>

    <div id="loader1" style="margin-top:-20px; display:none">
    <center>  <div class="word" style="color:white">BLOCKCHAIN &nbsp PROCESSING</div></center>

        </div>
        <div id="loader2" style="margin-top:-20px;display:none ">
          <center><div class="word" style="color:white">DATA&nbspVERIFICATION&nbspENCRYPTION</div></center>

            </div>

      </center>
    </div>
    <div class="main-agileinfo" style="margin-top:0px">
  <center><span class = "error"><?php echo $errcovered_value;?></span></center>

			<div class="agileits-top">
			<form  action="index.php"  method="post">
          <label class="label" >CCB NAME</label>
					<input class="text" type="text" name="ccb_name" placeholder="CORPORATE COMMODITY BUYER" value="<?php echo $ccb_name; ?>"  required="" id="name">
          <span class = "error"> <?php echo $errccb_name;?></span>
          <label class="label" >REP NAME</label>
					<input class="text" type="text" name="rep_name" placeholder="CCB Representative Name" value="<?php echo $rep_name; ?>" required id="name3"  >
          <span class = "error"> <?php echo $errrep_name;?></span>
          <label class="label" >EMAIL</label>
					<input class="text" type="text" name="email" placeholder="CCB Representative Email Address" value="<?php echo $email; ?>" required id="name3"  >
          <span class = "error"> <?php echo $erremail;?></span>
          <label class="label" >CONTRACT NAME</label>
					<input class="text" type="text" name="contract_name" placeholder="Enter a Name for this Contract" value="<?php echo $contract_name; ?>" required id="name3"  >
          <span class = "error"> <?php echo $errcontract_name;?></span>

          <label class="label">BUYER ADDRESS</label>
          <?php
        include ('config1.php');
        $sql= $conn->query("SELECT * FROM general_ledger where role='buyer' ");
        $result=$sql->num_rows;

        ?>
      <select  class="select" type="text" style="height:42px" id="state" name="buyer_address" value="<?php echo $buyer_address; ?>"  placeholder="location">
        <option value="" class="select" style="background-color:rgb(132,190,101)"  type="text" > Select Your Buyer Address</option>
         <?php
       if ($result>0){
        while($row = $sql->fetch_assoc()){
        echo'<option class="select" type="text" style="background-color:rgb(132,190,101)"  value="'.$row['address'].'" >' .$row['address'].'</option>';
        }
      }else{
        echo '<option class="select" style="background-color:rgb(132,190,101)"  type="text" value="">Buyer not available</option>';
      }
         ?>
        }
        <span class = "error"> <?php echo $errbuyer_address;?></span>
        </select>

          <label class="label">COMMODITY</label>
          <?php
        include ('configz.php');
        $sql= $conn->query("SELECT * FROM main_commodities ");
        $result=$sql->num_rows;

        ?>
      <select  class="select" type="text" style="height:42px" id="state" name="commodity" value="<?php echo $commodity ?>"  >
        <option value="" class="select" style="background-color:rgb(132,190,101)"  type="text" > Select Your Commodity</option>
         <?php
       if ($result>0){
        while($row = $sql->fetch_assoc()){
        echo'<option class="select" type="text" style="background-color:rgb(132,190,101)"  value="'.$row['id'].'" >' .$row['comm_name'].'</option>';
        }
      }else{
        echo '<option class="select" style="background-color:rgb(132,190,101)"  type="text" value="">Commodity not available</option>';
      }
         ?>
        }
        <span class = "error"> <?php echo $errcommodity;?></span>
        </select>

          <label class="label" >PRICE</label>
					<input class="text" type="number"  name="price" placeholder="Enter the Price" value="<?php echo $priceE; ?>"  required=""  >
          <span class = "error"><?php echo $errprice;?><?php echo $errprice;?></span>
          <label class="label" >QUANTITY</label>
					<input class="text" type="number"  name="quantity" placeholder="Enter the Quantity" value="<?php echo $quantity; ?>"  required=""  >
          <span class = "error"><?php echo $errquantity;?></span>
          <label class="label" >COVERED VALUE</label>
					<input class="text" type="number"  name="covered_value" placeholder="Enter the Covered value (amount)" value="<?php echo $covered_valueE; ?>"  required=""  >
          <span class = "error"><?php echo $errcovered_value;?></span>
        <label class="label" >ALLOCATED COMMISION (PERCENTAGE)</label>
        <input class="text" type="number"  name="extra_sell_price" placeholder="Enter Allocated commission in Percentage" value="<?php echo $extra_sell_priceE; ?>"  required="" >
        <span class = "error"> <?php echo $errextra_sell_price;?></span>
        <label class="label" >DURATION OF CONTRACT</label>
        <input class="text" type="number"  name="duration" placeholder="Enter the Duration of contract in days" value="<?php echo $duration; ?>"  required=""  >
        <span class = "error"> <?php echo $errduration;?></span>
        <label class="label">OPERATOR</label>
          <?php
        include ('config1.php');
        $sql= $conn->query("SELECT * FROM general_ledger where role='operator' ");
        $result=$sql->num_rows;

        ?>
      <select  class="select" type="text" style="height:42px" id="state" name="operator" value="<?php echo $buyer_address; ?>"  placeholder="location">
        <option value="" class="select" style="background-color:rgb(132,190,101)"  type="text" > Select An Operator</option>
         <?php
       if ($result>0){
        while($row = $sql->fetch_assoc()){
        echo'<option class="select" type="text" style="background-color:rgb(132,190,101)"  value="'.$row['address'].'" >' .$row['address'].'</option>';
        }
      }else{
        echo '<option class="select" style="background-color:rgb(132,190,101)"  type="text" value="">Buyer not available</option>';
      }
         ?>
        }
        <span class = "error"> <?php echo $errbuyer_address;?></span>
        </select>
        <label class="label">DELIVERY STATE</label>
          <?php
             include ('configz.php');
             $sql= $conn->query("SELECT * FROM state ");
             $result=$sql->num_rows;

             ?>
         <select class="select" type="text" style="height:42px" name="state" id="state" value="<?php echo $state; ?>"  placeholder="state" >
             <option value="" class="select" style="background-color:rgb(132,190,101)"  type="text"> Select Delivery State</option>
            <?php
          if ($result>0){
           while($row = $sql->fetch_assoc()){
             echo'<option class="select" type="text" style="background-color:rgb(132,190,101)"  value="'.$row['state'].'" data-id="'.$row['id_no'].'" ">' .$row['state'].'</option>';
           }
         }else{
           echo '<option class="select" type="text" style="background-color:rgb(132,190,101)"  value=""> state not available</option>';
         }
            ?>
           }

<span class = "error"> <?php echo $errstate;?></span>
           </select>
        
        <label class="label">ALLOW INDEPENDENT OFFTAKER</label>
    <select  class="select" type="text" style="height:42px" id="state" name="allow_independent_offtaker" value="<?php echo $allow_independent_offtaker; ?>"  >
      <option value="" class="select" type="text" style="background-color:rgb(132,190,101)" >Allow Independent Offtaker</option>
      <option value="true" class="select" type="text" style="background-color:rgb(132,190,101)" > TRUE</option>
      <option value="false" class="select" type="text" style="background-color:rgb(132,190,101)" >FALSE</option>
      <span class = "error"> <?php echo $errallow_independent_offtaker;?></span>
      </select>
      

					<input type="submit" value="CREATE COTRACT" id="btn-submit" name="cent" style="background-color: rgb(135,192,100); border:0px">

				</form>

  <p style="font-size:10px"><a href="../gorderOppn.php"> Click here to Cancel or  Return back!</a></p>
			</div>
		</div>
		<!-- copyright -->
		<div class="colorlibcopy-agile">
			<p>© 2019 Agrikore Blockchain All rights reserved | Powered by Cellulant <a href="https://colorlib.com/" target="_blank"></a></p>
    </div>
      <script src="http://code.jquery.com/jquery-1.10.2.js"></script>



    <script src="jsLoader/index.js"></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/lettering.js/0.6.1/jquery.lettering.min.js'></script>

      <script src="js7/index.js"></script>
</body>
</html>
