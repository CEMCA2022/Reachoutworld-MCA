<?php

//include ('fundScript/config.php');
include("configzZ.php");

$return_arr = array();
$redeem_code = $_GET['redeem_code'];
// $role = 'offtaker';

$sql = "SELECT name, phone,quantity,size, address FROM order_table WHERE  redeem_code = ?";

if($stmt = mysqli_prepare($conn, $sql)){
    // Bind variables to the prepared statement as parameters
    mysqli_stmt_bind_param($stmt, "s", $param_address);

    // Set parameters
    $param_address = $redeem_code;


    // Attempt to execute the prepared statement
    if(mysqli_stmt_execute($stmt)){
        // Store result
        mysqli_stmt_store_result($stmt);

        if(mysqli_stmt_num_rows($stmt) == 1){
            mysqli_stmt_bind_result($stmt, $name, $phone, $quantity,$size, $address);
            if(mysqli_stmt_fetch($stmt)){
                $return_arr = array(
                    "name" => $name,
                    "phone" => $phone,
                    "size" => $size,
                    "quantity" => $quantity,
                    "address" => $address,
                );
            }
        }
    }
}

// Close statement
mysqli_stmt_close($stmt);

// Encoding array in JSON format
echo json_encode($return_arr);
