<?php session_start();
include("functions.php");
error_reporting(0);
// variable declaration

$farmers = fetchFromDatabase('localhost', 'ebube', 'advancegrace', 'tanadi', 'agent_table');
$status = 0;

		$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');
if (isset($_POST['login'])) {
	$clearance_Id = mysqli_real_escape_string($db, $_POST['clearance_Id']);
	$password = mysqli_real_escape_string($db, $_POST['password']);

	if (empty($clearance_Id)) {
		$message = "clearance Id is required";
	}
	if (empty($password)) {
		$message = "Password is required";
	}
	$password_1 = md5($password);
	$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');
	$check = mysqli_query($db, "SELECT * FROM agent_table WHERE  clearance_Id='$clearance_Id'");
	$row = $check->fetch_assoc();
		$statusCode= $row['status'];
	// $userAddress = $row['userAddress'];
	if($statusCode == 1){
		$errors = "Username is required";
		$message ="Sorry this agent is Logged-in already.";
	}


	if (count($errors) == 0) {

		$query = "SELECT * FROM agent_table WHERE clearance_Id='$clearance_Id' AND password='$password_1'";
		$results = mysqli_query($db, $query);

		if (mysqli_num_rows($results) == 1) {
			$status = 1;
				updateAgentStatusLogin('localhost', 'ebube', 'advancegrace', 'tanadi', 'agent_table', $clearance_Id);
			$_SESSION['clearance_Id'] = $clearance_Id;
		 $_SESSION['last_login_timestamp'] = time();
			header('location: ../redeemOrder.php');

			if((time() - $_SESSION['last_login_timestamp']) > 180) // 900 = 15 * 60
														{
																			session_destroy();
																			header("location:../redeem/agent/logout.php");
																			updateAgentStatusLogout('localhost', 'ebube', 'advancegrace', 'tanadi', 'agent_table', $clearance_Id);
																					exit;
														}
														else
														{
																			$_SESSION['last_login_timestamp'] = time();
																			echo "<h1 align='center'>".$_SESSION["name"]."</h1>";
																			echo '<h1 align="center">'.$_SESSION['last_login_timestamp'].'</h1>';
																			echo "<p align='center'><a href='logout.php'>Logout</a></p>";
														}


		}else {
			$message ="Wrong clearance_Id/password combination";
		}
	}
}

?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Agent Login</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="./style.css">


</head>

<body>


<div class="container">
  <div class="info">
    <h1>Tanadi Discount </h1><span> Redeemtion Agent Login</span>
		<center style="color:red"><?php echo $message ?></center>
  </div>

</div>

<div class="form" action="login.php"  method="post">

  <div class=""><img src="images/protection2.png"/></div>
  <form class="register-form">
    <input type="text" placeholder="name"/>
    <input type="password" placeholder="password"/>
    <input type="text" placeholder="email address"/>
    <button>create</button>
    <p class="message">Already registered? <a href="#">Sign In</a></p>
  </form>
  <form class="login100-form validate-form flex-sb flex-w" action="login.php"  method="post">
        <input type="text" placeholder="Clearance ID" name="clearance_Id" style="text-align:center"/>
    <input type="password" placeholder="password" name="password" style="text-align:center"/>
    <button name="login">login</button>

  </form>
</div>
<video id="video" autoplay="autoplay" loop="loop" poster="polina.jpg">
  <source src="http://andytran.me/A%20peaceful%20nature%20timelapse%20video.mp4" type="video/mp4"/>
</video>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>



    <script  src="./script.js"></script>




</body>

</html>
