<?php
include("functionsF.php");
session_start();

	$name="";
	$phone="";
	$quantity="";
	$address="";

	$status=0;
	$errors = array();
	$messages= array();
	$_SESSION['success'] = "";



	// connect to database
	$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');

	// REGISTER USER
	if (isset($_POST['redeem'])) {

		// receive all input values from the form

		$redeem_quantity= mysqli_real_escape_string($db, $_POST['redeem_quantity']);
		$phone= mysqli_real_escape_string($db, $_POST['phone']);
		$redeem_code= mysqli_real_escape_string($db, $_POST['redeem_code']);


		$db = mysqli_connect('localhost', 'ebube', 'advancegrace', 'tanadi');
		$check = mysqli_query($db, "SELECT name,quantity, status, address FROM order_table WHERE  redeem_code='$redeem_code'");
		$row = $check->fetch_assoc();
		 $quantity1 = $row['quantity'];
			 $stausCode= $row['status'];
		// $userAddress = $row['userAddress'];
		if($redeem_quantity > $quantity1){
			$errredeem_quantity='<p>Please Your Redeem Quantity is Greater that your Quantity</p>';
			array_push($errors, $errredeem_quantity);
		}


		// form validation: ensure that the form is correctly filled

		// register user if there are no errors in the form
		if (count($errors) == 0) {

			    if($stausCode == 0)

					{
			            updateOrderTable('localhost', 'ebube', 'advancegrace', 'tanadi', 'order_table', $redeem_quantity, $redeem_code);
															$messagesSuccess = "Congratulations! Order REDEEMED Successfully";

							}else{
									$messagesError = "Sorry this Redeemtion Order Code has been REDEEMED (no longer valid)";
							}


				}
}


?>
