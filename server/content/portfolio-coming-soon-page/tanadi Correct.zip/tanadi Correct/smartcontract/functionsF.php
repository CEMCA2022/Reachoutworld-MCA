<?php
//This is the function to get account
function getToken($username, $password)
{
    $url = "https://www.agrikore.net/auth/login";

    $fields = [
        'name' => $username,
        'password' => $password
    ];

    //url-ify the data for the POST
    $fields_string = http_build_query($fields);

    //open connection
    $ch = curl_init();

    //set the url, number of POST vars, POST data
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_POST, count($fields));
    curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

    //So that curl_exec returns the contents of the cURL; rather than echoing it
    curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);

    //execute post
    $result = curl_exec($ch);
    $array_response = json_decode($result, true);
    $token = "";
    if(isset($array_response['token']))
    {
        $token = $array_response['token'];
    }
    return $token;
}

//This is the function Register Users
function register($username, $password, $token)
{
    $url = "https://www.agrikore.net/auth/register";

    $fields = [
        'name' => $username,
        'password' => $password
    ];

    //url-ify the data for the POST
    $fields_string = http_build_query($fields);

    //open connection
    $ch = curl_init();

    //set the url, number of POST vars, POST data
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_POST, count($fields));
    curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

    //So that curl_exec returns the contents of the cURL; rather than echoing it
    curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);

    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'x-access-token: '.$token
    ));

    //execute post
    $result = curl_exec($ch);
    $array_response = json_decode($result, true);
    $token = $array_response['token'];
    return $token;
}


function getAddress($password, $token)
{
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://www.agrikore.net/keystore/{%22op%22:%22createkeyadv%22,%20%22pwd%22:%22$password%22}",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);
    return $array_response['address'];
}


function addFarmer($admin_address, $admin_password, $farmer_address, $farmer_name, $location, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"addfarmer", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$farmer_address.'", "name":"'.$farmer_name.'", "loc":"'.$location.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/farmer/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));


    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}


// This is the Function to add genesis Money into the system
function addGenesis($admin_address, $admin_password, $nairaReserve_address, $Amount, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"importtoken", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "to":"'.$nairaReserve_address.'", "val":"'.$Amount.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/naira/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));


    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}


// This is the function to fund the CCB account
function FundCCBaccount($admin_address, $admin_password, $address, $amount, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"importtoken", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "to":"'.$address.'", "val":"'.$amount.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/naira/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}

// This is the function to fund the Offtaker account
function FundOfftakeraccount($admin_address, $admin_password, $address, $amount, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"importtoken", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "to":"'.$address.'", "val":"'.$amount.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/naira/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}


//This is the function to Fund naira reserve
function fundNairaReserve($admin_address, $admin_password, $address, $amount, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"transfertoreserve", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "from":"'.$address.'", "val":"'.$amount.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/naira/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}

//This is the function to Fund naira reserve
function NairaReservetoAddress($admin_address, $admin_password, $address, $amount, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"transferfromreserve", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "to":"'.$address.'", "val":"'.$amount.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/naira/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}


//This is the function to Buy from Mula reserve
function BuyMulaWithNaira($admin_address, $admin_password, $address, $amount, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"buymulafor", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$address.'", "val":"'.$amount.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/naira/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}





//This is the function to Fund mula Reserve
function fundMulaReserve($admin_address, $admin_password, $address, $amount, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"buymulafor", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$address.'", "val":"'.$amount.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/naira/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}


//This is the function to Fund mula Reserve
function fundMulaReserve2($admin_address, $admin_password, $address, $amount, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"buymulafor", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "addr":"'.$address.'", "val":"'.$amount.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/naira/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}






//This is the function to transfer currency to Naira reserve from any account

function accountToReserve($admin_address, $admin_password, $address, $Amount, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"transfertoreserve", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "from":"'.$address.'", "val":"'.$Amount.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/naira/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}

//This is the function to Transfer from Mula reserve to any account
function mulaReserveToAnyAccount($admin_address, $admin_password, $address, $amount, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"transferfromreserve", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "to":"'.$address.'", "val":"'.$amount.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/mula/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}

//This is the function to Transfer from Naira reserve to any account
function nairaReserveToAnyAccount($admin_address, $admin_password, $address, $Amount, $token)
{
    $curl = curl_init();

    $parameter = curl_escape($curl,'{"op":"transferfromreserve", "admin":"'.$admin_address.'", "adminpwd":"'.$admin_password.'", "to":"'.$address.'", "val":"'.$Amount.'"}');

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.agrikore.net/naira/unsafe/ad/'.$parameter,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "x-access-token: $token"
        ),
    ));

    $result = curl_exec($curl);
    $array_response = json_decode($result, true);

    if (curl_error($curl)) {
        $error_msg = curl_error($curl);
    }
    curl_close($curl);

    if (isset($error_msg)) {
        // TODO - Handle cURL error accordingly
        echo($error_msg);
    }

    return $array_response;
}



// This is the Function to fetch from Database
function fetchFromDatabase($host, $user, $password, $database, $table)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $query = "select * from $table";
    $output = array();
    if($result = mysqli_query($conn, $query))
    {
        while($r = mysqli_fetch_assoc($result))
        {
            array_push($output, $r);
        }
    }
    else
    {
        $err = mysqli_error($conn);
        mysqli_close($conn);
        die("SQL Error: $err\r\n");
    }

    return $output;
}


// this is the Update status function Mula reserve balance
function updateAddressStatusM($host, $user, $password, $database, $table, $row_id, $MulaReserveBalance)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set MulaReserveBalance='$MulaReserveBalance' , status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}


// This is the function to update the CCB ledger
function updateAddressStatusCCBledger($host, $user, $password, $database, $table, $row_id)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
       echo "Record updated successfully";
    } else {
       echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

//  This  is the function to update the CCB Equivalent Mula
function updateAddressStatusCCBledgerMula($host, $user, $password, $database, $table, $amount, $row_id)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set CCB_MULA='$amount', CCBbalance =' ', status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}


//  This  is the function to update the general_ledger
function updateOrderTable($host, $user, $password, $database, $table, $redeem_quantity, $redeem_code)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

  //  $sql = "update $table set mula= mula + '$mulaIN', where address=$address";
    $sql = "update $table set redeem_quantity= '$redeem_quantity', status=1 where redeem_code='$redeem_code'";
    if ($conn->query($sql) === TRUE) {
       // echo "Order Redeemed Successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

//  This  is the function to update the general_ledger
function updateBuyerGeneralLedgerNaira($host, $user, $password, $database, $table, $naira, $address)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

  //  $sql = "update $table set mula= mula + '$mulaIN', where address=$address";
    $sql = "update $table set naira= naira + '$naira' where address='$address' ";
    if ($conn->query($sql) === TRUE) {
      //  echo "Record updated successfully";
    } else {
       //echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}



//  This  is the function to update the Offtaker Equivalent Mula
function updateAddressStatusOfftakerledgerMula($host, $user, $password, $database, $table, $amount, $row_id)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set OFFTAKER_MULA='$amount', offtaker_balance =' ', status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}




// This is the function to update the Offtaker ledger
function updateAddressStatusOfftakerledger($host, $user, $password, $database, $table, $row_id)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}


// this is the Update status function Naira reserve balance
function updateAddressStatusN($host, $user, $password, $database, $table, $row_id, $NairaReserveBalance)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "update $table set NairaReserveBalance='$NairaReserveBalance' , status=1 where id=$row_id";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}

// InsertGorderLedger('localhost', 'root', '', 'agrikorefund', 'gorder_ledger',  $username, $password1, $buyer_address, $CCB_name);
//This is the function to insert into the Guarranteed order Approval Database
function InsertGorderLedger($host, $user, $password, $database, $table, $username, $password1, $buyer_address, $amount)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set buyer_username'$username', buyer_password= '$password1', buyer_address= '$buyer_address', CCB_MULA= '$amount'";
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
//This is the function to insert into the Guarranteed order Approval Database
function InsertTransaction($host, $user, $password, $database, $table, $initiator, $wallet, $amount,$userAddress,$channel, $TransactionToken)
{
    $conn = mysqli_connect($host, $user, $password, $database);
    if(!$conn)
    {
        die("Could not connect: ".mysqli_connect_error());
    }

    $sql = "insert $table set initiator='$initiator', towallet= '$wallet', amount= '$amount', userAddress='$userAddress', channel='$channel', TransactionToken='$TransactionToken'";
    if ($conn->query($sql) === TRUE) {
        //echo "Record updated successfully";
    } else {
       // echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
