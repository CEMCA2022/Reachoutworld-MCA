$( document ).ready(function() {
	var table = $('#buyer').DataTable( {
		"ajax": "dataB.php",
		"bPaginate":true,
		"bProcessing": true,
		"pageLength": 5,
		"columnDefs": [{
        "targets": -9,
        "visible": false,
      }],
		"columns": [
			{ mData: 'Id' } ,
			{ mData: 'name' },
			{ mData: 'quantity' },
			{ mData: 'redeem_quantity' },
			{ mData: 'phone' },
			{ mData: 'address' },
			{ mData: 'redeem_code' },
		 { mData: 'agent_name' },
			{ mData: 'status' },
			{ mData: 'register_date' },



		]
	});
	setInterval( function () {
		table.ajax.reload(null, false);
	}, 5000 );
});
// This is to view Offtaker Database
$( document ).ready(function() {
	var table = $('#offtaker').DataTable( {
		"ajax": "dataRedeem.php",
		"bPaginate":true,
		"bProcessing": true,
		"pageLength": 5,
		"columns": [
			{ mData: 'Id' } ,
			{ mData: 'name' },
			{ mData: 'phone' },
			{ mData: 'redeem_quantity' },
			{ mData: 'redeem_code' },
			{ mData: 'agent_name' },
			{ mData: 'redeem_date' }

		]
	});
	setInterval( function () {
		table.ajax.reload(null, false);
	}, 5000 );
});

// // This is to view Buyer Database
// $( document ).ready(function() {
// 	var table = $('#buyer').DataTable( {
// 		"ajax": "dataB.php",
// 		"bPaginate":true,
// 		"bProcessing": true,
// 		"pageLength": 5,
// 		"columns": [
// 			{ mData: 'Id' } ,
// 			{ mData: 'Username' },
// 			{ mData: 'Password' },
// 			{ mData: 'Buyer_name' },
// 			{ mData: 'Location' },
// 			{ mData: 'Address' },
// 			{ mData: 'Status' }
// 		]
// 	});
// 	setInterval( function () {
// 		table.ajax.reload(null, false);
// 	}, 5000 );
// });
//
// // This is to view Loaner Database
$( document ).ready(function() {
	var table = $('#loaner').DataTable( {
		"ajax": "dataL.php",
		"bPaginate":true,
		"bProcessing": true,
		"pageLength": 5,
		"columns": [
			{ mData: 'Id' } ,
			{ mData: 'Username' },
			{ mData: 'Password' },
			{ mData: 'Loaner_name' },
			{ mData: 'Loaner_loc' },
			{ mData: 'Address' },
			{ mData: 'Status' }
		]
	});
	setInterval( function () {
		table.ajax.reload(null, false);
	}, 5000 );
});

// This is to view Certifier Database
$( document ).ready(function() {
	var table = $('#certifier').DataTable( {
		"ajax": "dataCt.php",
		"bPaginate":true,
		"bProcessing": true,
		"pageLength": 5,
		"columns": [
			{ mData: 'Id' } ,
			{ mData: 'Username' },
			{ mData: 'Password' },
			{ mData: 'Certifier_name' },
			{ mData: 'Location' },
			{ mData: 'Fixed_rate' },
			{ mData: 'Percentage_rate' },
			{ mData: 'Address' },
			{ mData: 'Comm' },
			{ mData: 'Status' }
		]
	});
	setInterval( function () {
		table.ajax.reload(null, false);
	}, 5000 );
});
// This is to view Location Database
$( document ).ready(function() {
	var table = $('#location').DataTable( {
		"ajax": "dataLoc.php",
		"bPaginate":true,
		"bProcessing": true,
		"pageLength": 5,
		"columns": [
			{ mData: 'Id' },
			{ mData: 'Location_name' },
			{ mData: 'Location_coord' },
			{ mData: 'Country' },
			{ mData: 'State' },
			{ mData: 'Locality' },
			{ mData: 'Postal' },
			{ mData: 'Status' }
		]
	});
	setInterval( function () {
		table.ajax.reload(null, false);
	}, 5000 );
});
