$( document ).ready(function() {
	var table = $('#buyer').DataTable( {
		"ajax": "dataB.php",
		"bPaginate":true,
		"bProcessing": true,
		"pageLength": 5,
		"columns": [
			{ mData: 'Id' } ,
			{ mData: 'name' },
			{ mData: 'quantity' },
			{ mData: 'redeem_quantity' },
			{ mData: 'phone' },
			{ mData: 'address' },
			{ mData: 'redeem_code' },
		 { mData: 'agent_name' },
			{ mData: 'status' },
			{ mData: 'register_date' }



		]
	});
	setInterval( function () {
		table.ajax.reload(null, false);
	}, 5000 );
});
// This is to view Offtaker Database
$( document ).ready(function() {
	var table = $('#redemption').DataTable( {
		"ajax": "dataRedeem.php",
		"bPaginate":true,
		"bProcessing": true,
		"pageLength": 5,
		"columns": [
			{ mData: 'Id' } ,
			{ mData: 'name' },
			{ mData: 'phone' },
			{ mData: 'redeem_quantity' },
						{ mData: 'amount' },
			{ mData: 'redeem_code' },
			{ mData: 'agent_name' },
			{ mData: 'redeem_date' }
		]
	});
	setInterval( function () {
		table.ajax.reload(null, false);
	}, 5000 );
});
$( document ).ready(function() {
	var table = $('#tokenTable').DataTable( {
		"ajax": "dataToken.php",
		"bPaginate":true,
		"bProcessing": true,
		"pageLength": 5,
		"columns": [
			{ mData: 'Id' } ,
			{ mData: 'token' },
			{ mData: 'status' },
			{ mData: 'date' }

		]
	});
	setInterval( function () {
		table.ajax.reload(null, false);
	}, 5000 );
});

// // This is to view Loaner Database
$( document ).ready(function() {
	var table = $('#agent').DataTable( {
		"ajax": "dataAgent.php",
		"bPaginate":true,
		"bProcessing": true,
		"pageLength": 5,
		"columns": [
			{ mData: 'Id' } ,
			{ mData: 'name' },
			{ mData: 'phone' },
			{ mData: 'clearance_Id' },
			{ mData: 'password' },
			{ mData: 'status' },
			{ mData: 'date' }

		]
	});
	setInterval( function () {
		table.ajax.reload(null, false);
	}, 5000 );
});


// This is to view Location Database
$( document ).ready(function() {
	var table = $('#location').DataTable( {
		"ajax": "dataLoc.php",
		"bPaginate":true,
		"bProcessing": true,
		"pageLength": 5,
		"columns": [
			{ mData: 'Id' },
			{ mData: 'Location_name' },
			{ mData: 'Location_coord' },
			{ mData: 'Country' },
			{ mData: 'State' },
			{ mData: 'Locality' },
			{ mData: 'Postal' },
			{ mData: 'Status' }
		]
	});
	setInterval( function () {
		table.ajax.reload(null, false);
	}, 5000 );
});
